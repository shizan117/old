@extends ('admin.layouts.master')
@section('content')
    <div class="warningBox text-center pt-5">
        <div class="innerSection">
            <h1 style="font-size: 35px; font-weight: 400; color: red;">Mikrotik Connection Error!</h1>
            <h3 style="font-size: 25px; font-weight: 400; color: yellow;">Please check the Server connection with Mikrotik
                and try again...</h3>
        </div>
    </div>
@endsection
