<footer class="footer text-center">
    Made With <i class="fa fa-heart"></i> by <a href="http://deelko.com" target="_blank">Deelko</a>
</footer>